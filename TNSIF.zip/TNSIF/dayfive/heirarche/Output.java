package com.tnsif.dayfive.heirarche;

public class Output {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Sbi s =new Sbi("India","B2334","Banglore");
       Hdfc h=new Hdfc("India","M562w","Mysore");
       
       System.out.println(s);
       System.out.println(h);
	}

}
