package com.tnsif.dayfive.multilevel;

public class MultiDemo {

	public static void main(String[] args) {


		 City city = new  City();
		 city.setCityName("Bangalore");
		 city.setArea(234.9f);
		 city.setStateName("karnataka");
		 city.setLanguage("kannada");
		 city.setCountryName("india");
		 city.setCountryCapital("delhi");
		 
		 System.out.println(city);
		 
	}

}
