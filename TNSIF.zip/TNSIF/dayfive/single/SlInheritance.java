package com.tnsif.dayfive.single;

public class SlInheritance {

	public static void main(String[] args) {

		Student obj = new Student("kumar","a32413","bangalore",123,"reva");
		
		System.out.println(obj);
	}

}
