package com.tnsif.dayfour.secondpackage;

import com.tnsif.dayfour.firstpackage.Base;

public class Executor {

	public static void main(String[] args) {
		
		Base obj = new Base();
		
		obj.publicMethod();
		

	}

}
