package com.tnsif.dayfour.firstpackage;

public class Executor {

	public static void main(String[] args) {

		 Base obj = new Base ();
		 
		 obj.defaultMethod();
		 obj.protectedMethod();
		 obj.publicMethod();
		

	}

}
