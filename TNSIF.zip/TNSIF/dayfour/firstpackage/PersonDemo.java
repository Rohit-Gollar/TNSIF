package com.tnsif.dayfour.firstpackage;

public class PersonDemo {

	public static void main(String[] args) {

		Person obj = new Person();
		obj.setName("kumar");
		obj.setAddress("bangalore");
		obj.setAge(40);
		
		System.out.println(obj);

	}

}
