package com.tnsif.dayten.instanceofint;
public interface Phone {
	void call();

	void sms();
}

