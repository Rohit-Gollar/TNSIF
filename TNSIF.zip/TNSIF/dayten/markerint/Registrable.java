package com.tnsif.dayten.markerint;

public interface Registrable {

}
