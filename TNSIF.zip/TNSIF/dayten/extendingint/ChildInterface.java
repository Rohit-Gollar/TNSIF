package com.tnsif.dayten.extendingint;

public interface ChildInterface extends InterfaceOne {
	void show();
}