package com.tnsif.dayten.extendingint;

interface InterfaceOne{  
	  void print();  
	}  
