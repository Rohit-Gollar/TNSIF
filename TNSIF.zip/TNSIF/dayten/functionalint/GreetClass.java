package com.tnsif.dayten.functionalint;

public class GreetClass implements GreetInterface {
	
	public String greet()
	{
		return "welcome to Java";
	}

}
