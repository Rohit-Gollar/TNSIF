package com.tnsif.dayten.functionalint;

@FunctionalInterface
public interface GreetInterface {
	
	public String greet();


}
