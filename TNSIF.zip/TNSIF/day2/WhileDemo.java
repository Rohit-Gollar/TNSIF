package com.tnsif.day2;

public class WhileDemo {
	public static void main(String[] args) 
	{
		int i=99;
		while(i<=100)
		{
			System.out.println(i);
			i++;
		}
	}
}