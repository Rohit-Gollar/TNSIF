package com.tnsif.dayeight;

public class SBI extends RBI {
	
	@Override
 public  float getRateOfInterst()
	{
		return 7.5f;
	}

}
