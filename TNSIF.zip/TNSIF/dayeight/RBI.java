package com.tnsif.dayeight;

//super class
public class RBI {
	float interest;
	public float getRateOfInterst()
	{
		return 6.7f;
	}

}
