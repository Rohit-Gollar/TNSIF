package com.tnsif.dayeight;

public class HDFC extends RBI{
	
	@Override
	public float getRateOfInterst()
	{
		return 8.8f;
	}

}
