package com.tnsif.dayeight;

public class ICICI extends RBI{
	@Override
public	float getRateOfInterst()
	{
		return 9.7f;
	}

}
