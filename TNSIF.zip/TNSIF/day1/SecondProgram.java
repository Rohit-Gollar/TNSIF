package com.tnsif.day1;

public class SecondProgram {

	public static void main(String[] args) {


	double firstNumber =10d;
		double secondNumber = 20d;
		
		double result;
		result = firstNumber  / secondNumber;
		System.out.println("result is " +result);
		

	}

}
