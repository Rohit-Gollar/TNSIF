package com.tnsif.day1;

public class ThirdProgram {

	public static void main(String[] args) {
		
		//Implicit Type casting
		
		int a = 10;
		float b = a;
		System.out.println(b);
		
		
		float c= 100.001f;
		double d = c;
		System.out.println(d);
		
		//Explicit Type casting 
		
		double aa = 100.7868686d;
		int  bb = (int) aa;
		System.out.println(bb);
		
		
		
		int cc = 65;
		char dd = (char) cc;
		System.out.println(dd);
		
		
		

	}

}
