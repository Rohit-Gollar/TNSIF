package com.tnsif.day1;

public class FirstProgram {

	public static void main(String[] args) {
		
		System.out.println("welcome!");
		System.out.print("CSE!");
	}

}
